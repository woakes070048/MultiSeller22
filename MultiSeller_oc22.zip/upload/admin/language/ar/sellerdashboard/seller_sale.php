<?php

// Heading
$_['heading_title'] = 'اجمالي المبيعات الخاصة بالباعة';

// Text
$_['text_view'] = 'المزيد ...';
